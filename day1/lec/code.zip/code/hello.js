// alert( 'Hello, world!' );
// console.log('Hello from console log');
// document.write('Hello from document')
//
// // variables
// var name = "Ahmed";
// var age = 35;
// var isMarried = true;
//
// // Declaring Variable
// var userName;
// console.log(userName);
// // // // Assigning value
// userName = "Ahmed";
// console.log(userName);

//
//
// // Declaring multiple Variables
// var name = "Ahmed", age =35, isMarried = false;
// // /* Longer declarations can be written to span
// // multiple lines to improve the readability */
// var name = "ahmed",
// age = 21,
// isMarried = false;
//
//
// let name = "ahmed";
// let age = 11;
// let isStudent = true;
// console.log(name, age, isStudent);

// console.log(isStudent);
// isStudent = false
// console.log(isStudent);
// // // Declaring constant
// const PI = 3.14;
// console.log(PI); // 3.14
// // // // Trying to reassign
// PI = 10; // error
//
//
// var userName = "ahmed";
// var userName1 = "ahmed";
// var user1Name = "ahmed";
// var 1userName = "ahmed"; XX
// var @userName = 'ahmed'; XX
// var _userName = "ahmed";
// var $userName = "ahmed";
//
// alert(userName);
// var uSerName = "Ahmed";
// alert(uSerName);
//
// var message;
// console.log(message);
// message = "Hello";
// message = "welcome";
// console.log(message);
//
// let message = 'Hello';
// let message;
// console.log(message);
// message = "Hello";
// console.log(message);
//
// let userName = "ahmed";
// let age = 20;
// let userName = "ahmed",
//   age = 20,
//   message = "Hello";
// let grade;
// var firstName;
//
// // const color;
// // color = "red"; XXX
//
// const color = "Red";
// // color = "Blue"; XXX
//

// {
//   let lastName = "Salah";
//   // var user = "Ahmed";
//
// }
// console.log(user);
// console.log(lastName);
// userName = "Ali";
// userName = "Ali";
// userName = "Hassan";
// var userName;

// console.log(userName);

// let userName;
// let userName ;
// console.log(userName);
// let let = '';  XX
 // these Functions hold user data
// console.log(userName);
// var userName;

// hjkhjkhjkhjkh
/*
wklwkr
rwlrklwkr
;wr;wlr
*/

// datatype
// String
//
// var a = 'Hi there!';  // using single quotes
// var b = "Hi there!";  // using double quotes
// var l = "Let's have a cup of coffee."; // single quote
// console.log(l);
// // inside double quotes
// var d = 'He said "Hello" and left.';  // double quotes
// // inside single quotes
// var c = 'We\'ll never give up.';     // escaping single
// // quote with backslash
// console.log(a, b , l, d, c );

//////// not today
// let firstName = "Ahmed";
// // let lastName = "Has";
// // let desc = 'This a simple" app';
// // desc = 'This a simple" "app';
// // desc = "This a simple 'app";
// // desc = 'This a simple "app';
// desc = `This a simple JS app for ${firstName} ${1 + 2}`;
// console.log(desc);
// // desc = "This a simple \nJS app for" + " " + firstName;
// desc = 'This a simple \n JS app for ${firstName} ${1 + 2}';

// number

// var a = 25;
// var b = 80.5;
// var c = 4.25e+6;
// or 4250000
// var d = 4.25e-6;
// 0.00000425
// console.log(a, b, c);
// // integer
// // floating-point number
// // exponential notation, same as 4.25e6
// // exponential notation, same as

// console.log(16 / 0);  // Output: Infinity
// console.log(-16 / 0); // Output: -Infinity
// console.log(16 / -0); // Output: -Infinity

// console.log("Some text" / 2);       // Output: NaN
// console.log("Some text" / 2 + 10);  // Output: NaN
// console.log(Math.sqrt(-1));         // Output: NaN

// Boolean -> true , false
// var isReading = true;   // yes, I'm reading
// var isSleeping = false; // no, I'm not sleeping
//
// var a = 2, b = 5, c = 10;
// console.log(b > a) // Output: true
// console.log(b > c) // Output: false


// Types Conversion
 // Number() converts to a Number,
 // String() converts to a
 // String, Boolean() converts to a Boolean.
 //
 // let firstNumber = 10;
 // let secondNumber = "5";
 // secondNumber = Number(secondNumber);
 // console.log(firstNumber / secondNumber);
 // console.log(firstNumber + secondNumber);

 // console.log(isNaN(Number("Ali")));

 // let isAdmin = true;
 // // console.log(typeof isAdmin);
 // let isAdminStr = String(isAdmin);
 // console.log(typeof isAdminStr);
 // "true"  true
 // let age = 20;
 // console.log(typeof age); // number
 // age = String(age);
 // console.log(typeof age); // string
 // let ageStr = String(age); // "20"
 // console.log(typeof ageStr); // string
 // let nullValue = null;
 // nullValue = String(nullValue);
 // console.log(typeof nullValue); // "null"

 // console.log(Boolean(0));
 // console.log(Boolean(null));
 // console.log(Boolean(undefined));
 // console.log(Boolean(NaN));
 // console.log(Boolean(""));
 // console.log(Boolean(''));
 // console.log(Boolean(``));
 // // truthy values
 // console.log(Boolean(" "));
 // console.log(Boolean("Ali"));
 // console.log(Boolean("null"));
 // console.log(Boolean("undefined"));
 // console.log(Boolean("NaN"));
 // console.log(Boolean("0"));
 // console.log(Boolean(1));
 // console.log(Boolean(123));

 //The Undefined Data Type
// var a;
// var b = "Hello World!";
// console.log(a) // Output: undefined
// console.log(b) // Output: Hello World!

// The Null Data Type
// var a = null;
// console.log(a); // Output: null
// var b = "Hello World!";
// console.log(b); // Output: Hello World!
// b = null;
// console.log(b) // Output: null


// The Object Data Type
// var emptyObject = {};
// var person = {"name": "Clark", "surname": "Kent", "age": 36};
// // console.log(person.age);
// // console.log(person["surname"]);
//
// // // For better reading
// var car = {
//     modal: "BMW X3",
//     color: "white",
//     doors: 5,
// }
//
// console.log(car);

//The Array Data Type
// var arr = []
// var colors = ["Red", "Yellow", "Green", "Orange"];
// var cities = ["London", "Paris", "New York", {Country: "Canda"}];
// alert(colors[1]);   // Output: Red
// alert(cities[2]);   // Output: New York
// //The Function Data Type
// function greeting(){
//   // code execute
//   document.write('Hello');
// }
//
// function greet(name){
//   console.log("before return");
//   return "Hello " + name; //
//   console.log("after return");
//
// }

// console.log(greet('ahmed'))
// console.log(greet('iti'))
// var firstName = 'php'
// console.log(greet(firstName))

// var add = function(x, y){
//   return x + y
// }
//
// var result = add(3 , 4)
// console.log(result);
// var greeting = function(){
//     return "Hello World!";
// }
// // Check the type of greeting variable
// alert(greeting());     // Output: Hello World!
//
//
// function createGreeting(name){
//     return "Hello, " + name;
// }
// function displayGreeting(greetingFunction, userName){
//     return greetingFunction(userName);
// }
// var result = displayGreeting(createGreeting, "Peter");
// alert(result); // Output: Hello, Peter

//The typeof Operator
// Numbers
// typeof 15;  // Returns: "number"
// typeof 42.7;  // Returns: "number"
// typeof 2.5e-4;  // Returns: "number"
// typeof Infinity;  // Returns: "number"
// typeof NaN;  // Returns: "number". Despite being "Not-A-
// Number"
// // Strings
// typeof '';  // Returns: "string"
// typeof 'hello';  // Returns: "string"
// typeof '12';  // Returns: "string". Number within quotes is
// typeof string
// // Booleans
// typeof true;  // Returns: "boolean"
// typeof false;  // Returns: "boolean"
// // Undefined
// typeof undefined;  // Returns: "undefined"
// typeof undeclaredVariable; // Returns: "undefined"
// // Null
// typeof Null;  // Returns: "object"
// // Objects
// typeof {name: "John", age: 18};  // Returns: "object"
// // Arrays
// typeof [1, 2, 4];  // Returns: "object"
// // Functions
// typeof function(){};  // Returns: "function"


// What are Operators in JavaScript
//
// var x = 10;
// var y = 4;
// alert(x + y); // 0utputs: 14
// alert(x - y); // 0utputs: 6
// alert(x * y); // 0utputs: 40
// alert(x / y); // 0utputs: 2.5
// alert(x % y); // 0utputs: 2

// // JavaScript Assignment Operators
//
var x; // Declaring Variable
// x = 10;
// // alert(x); // Outputs: 10
// // x = 20;
// x = x + 10
// x += 30; // x = x + 30
// alert(x); // Outputs: 50
// x = 50;
// x -= 20; // x = x - 20
// alert(x); // Outputs: 30
// x = 5;
// x *= 25; // x = x * 5
// alert(x); // Outputs: 125
// x = 50;
// x /= 10;
// alert(x); // Outputs: 5
// x = 100;
// x %= 15;
// alert(x); // Outputs: 10
//

// // JavaScript String Operators
// var str1 = "Hello";
// var str2 = " World!";
// alert(str1 + str2); // Outputs: Hello World!
// str1 += str2;
// alert(str1); // Outputs: Hello World!
//
// // JavaScript Incrementing and Decrementing
// // Operators
//
var x; // Declaring Variable
// x = 10;
// alert(++x); // Outputs: 11
// alert(x); //Outputs:11
// x = 10;
// alert(x++); // Outputs: 10
// alert(x); //Outputs:11
// x = 10;
// alert(--x); // Outputs: 9
// alert(x); //Outputs:9
// x = 10;
// alert(x--); // Outputs: 10
// alert(x); //Outputs:9

// -> if
// var x;
// // var y = 30;
// if(x > 20){
//     console.log('x > 20');
// } else if (x == 10) {
//   console.log('x== 10')
// } else if (x < 10) {
//   console.log('x < 10')
// }
// else{
//   console.log('x=false');
// }
// console.log('out of block if');


// //JavaScript Logical Operators
// var year = 2018;
// // // Leap years are divisible by 400 or by 4 but not 100
//
// if((year % 400 == 0) || ((year % 100 != 0) && (year % 4 == 0)))
// { alert(year + " is a leap year.");
// } else{
//   alert(year + " is not a leap year.");
// }
//

// // JavaScript Comparison Operators
// var x = 25;
// var y = 35;
// var z = "25";
// // alert(x == z); // Outputs: true
// // alert(x === z); // Outputs: false
// // alert(x != y); // Outputs: true
// // alert(x !== z); // Outputs: true
// // alert(x < y); // Outputs: true
// // alert(x > y); // Outputs: false
// // alert(x <= y); // Outputs: true
// alert(x >= y); // Outputs: false
//
// var message = "Hi there! Click OK to continue.";
// alert(message);
// /* The following line won't execute until you dismiss
// previous alert */
// alert("This is another alert box.");
// // Creating Prompt Dialog Box For Input
// var name = prompt("What's your name?");
// alert('your name is' + name);
// console.log(name);
// if(name.length > 0 && name != "null") {
//     document.write("Hi, " + name);
// } else {
//   document.write("Anonymous!");
// }
//
// var age = Number(prompt("What's your age?"));
//
// let isManager = confirm('Are you manager?')
// console.log(isManager);
// // JavaScript Conditional Statements
//
// var now = new Date();
// var dayOfWeek = now.getDay(); // Sunday - Saturday : 0 - 6
// if(dayOfWeek == 5) {
//     alert("Have a nice weekend!");
// }
//
// ////////////////
// var now = new Date();
// var dayOfWeek = now.getDay(); // Sunday - Saturday : 0 - 6
// if(dayOfWeek == 5) {
//     alert("Have a nice weekend!");
// } else {
//     alert("Have a nice day!");
// }
//
//
// var now = new Date();
// var dayOfWeek = now.getDay(); // Sunday - Saturday : 0 - 6
// if(dayOfWeek == 5) {
//     alert("Have a nice weekend!");
// } else if(dayOfWeek == 0) {
//     alert("Have a nice Sunday!");
// } else {
//     alert("Have a nice day!");
// }
//
// //The Ternary Operator
// var userType;
// var age = 21;
// if(age < 18) {
//     userType = 'Child';
// } else {
//     userType = 'Adult';
// }
// alert(userType); // Displays Adult
//  age? 'Child' : 'Adult;
// var age = 17;
// var userType = age < 18 ? 'Child' : 'Adult';
// alert(userType); // Displays Adult
// // //

// Next Sessions

// // Using the Switch...Case Statement
// switch(x){
//     case value1:
//         // Code to be executed if x === value1
//         break;
// }
// case value2:
//     // Code to be executed if x === value2
//     break;
// ... default:
// // Code to be executed if x is different from all values
//
//
// var d = new Date();
// switch(d.getDay()) {
//       case 0:
//              alert("Today is Sunday.");
//              break;
//       case 1:
//              alert("Today is Monday.");
//              break;
//       case 2:
//              alert("Today is Tuesday.");
// break;
// case 3:
//       alert("Today is Wednesday.");
//       break;
// case 4:
//       alert("Today is Thursday.");
//       break;
// case 5:
//       alert("Today is Friday.");
//       break;
//       case 6:
//             alert("Today is Saturday.");
//             break;
//       default:
//             alert("No information available for that day.");
//       break;
// }
//
//
// var d = new Date();
// switch(d.getDay()) {
//     default:
//         alert("Looking forward to the weekend.");
//         break;
//     case 6:
//         alert("Today is Saturday.");
//         break;
//     case 0:
// }
// alert("Today is Sunday.");
//
// // Multiple Cases Sharing Same Action
//
// var d = new Date();
// switch(d.getDay()) {
//     case 1:
//     case 2:
//     case 3:
//     case 4:
//     case 5:
//         alert("It is a weekday.");
//         break;
// case 0:
// case 6:
//     alert("It is a weekend day.");
//     break;
// default:
//     alert("Enjoy every day of your life.");
// }
